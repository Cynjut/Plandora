var TREE_NODES = [
	['Churrasco de Fim de Ano', null, null,
		['O qu� deve ser levado...', 'endereco_pg(link)', '_top'],
                ['Coca-Cola � b�o', 'http://www.slashdot.org', '_top'],
		['A Maria n�o vai...', null, null,
			['Ela vai sair...', 'http://www.javascriptkit.com', '_top'],
			['Outra bl�, bl�...', 'http://www.dynamicdrive.com', '_top'],
			['Mais bl�, bl�...', 'http://freewarejava.com', '_top'],
		],
	],
	['Tarefa ID:172 - Verificar Nome... ', null, null,
			['Requeriments', 'http://www.cnn.com', '_top'],
			['Specification Use Ca...', 'http://www.msnbc.com', '_top'],
			['Diagram...', 'http://news.bbc.co.uk', '_top'],
	]
];

